package comp380.util;


public class StringUtil 
{
	public static boolean isEmpty(String str)
	{
		if(str.equals(""))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
