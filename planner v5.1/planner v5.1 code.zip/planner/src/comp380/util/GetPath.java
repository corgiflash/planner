package comp380.util;
//get path of the resource file
public class GetPath
{
   public static void main(String args[])
   {
      //System.out.println(GetPath.getPath());
	   System.out.println(GetPath.getPath());
      
   }
   
   
   public static String getPath()
   {
      String curr=System.getProperty("user.dir");
      String returnValue="";
      for(int i=0;i<curr.length();i++)
      {
         if(curr.charAt(i)!='\\')
            returnValue=returnValue+curr.charAt(i);
         else
            returnValue=returnValue+curr.charAt(i)+curr.charAt(i);
      }
      
      //int index=returnValue.lastIndexOf("util");
      //returnValue=returnValue.substring(0,index);
      return returnValue;
   }
}
