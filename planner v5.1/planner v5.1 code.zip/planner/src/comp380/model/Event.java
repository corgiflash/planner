package comp380.model;

import java.util.*;
import java.io.*;

import comp380.util.GetPath;

public class Event implements Comparable<Event>
{
   private String eventID;
   private String userID;
   //event type 0 for self define event,1 for lecture, 2 for appointment,3 for moodle dead line,4 for exam
   //for due date and exam,just have start time
   private int type;
   private Calendar cSt;
   private Calendar cEd;
   private String description;
   private int weeklyRepeat=0;
   private int priority;
   
   
   public Event()
   {
   
   }
   
   
   //constructor to creat new event by UI
   public Event(String userID,int type,int year,int month,int date,int strHour,int strMin,int endHour,int endMin,String description,int weeklyRepeat,int priority)
   {
	   month=month-1;
      //set start and end time
      cSt=Calendar.getInstance();
      cSt.set(Calendar.YEAR,year);
      cSt.set(Calendar.MONTH,month);
      cSt.set(Calendar.DATE,date);
      cSt.set(Calendar.HOUR_OF_DAY,strHour);
      cSt.set(Calendar.MINUTE,strMin);
      
      cEd=Calendar.getInstance();
      cEd.set(Calendar.YEAR,year);
      cEd.set(Calendar.MONTH,month);
      cEd.set(Calendar.DATE,date);
      cEd.set(Calendar.HOUR_OF_DAY,endHour);
      cEd.set(Calendar.MINUTE,endMin);
      
      this.userID=userID;
      this.type=type;
      this.description=description;
      this.weeklyRepeat=weeklyRepeat;
      this.priority=priority;
      eventID=userID+cSt.getTimeInMillis()+cEd.getTimeInMillis();
   }
   //constructor to create new event by table
   public Event(String[] stra)
   {
      this(stra[1],Integer.parseInt(stra[2]),Integer.parseInt(stra[3]),Integer.parseInt(stra[4]),Integer.parseInt(stra[5]),Integer.parseInt(stra[6]),Integer.parseInt(stra[7]),Integer.parseInt(stra[8]),Integer.parseInt(stra[9]),stra[10],Integer.parseInt(stra[11]),Integer.parseInt(stra[14]));  
   }
  
   //getter
   public String getEventID()
   {
      return eventID;
   }
   public String getUserID()
   {
      return userID;
   }
   public int getType()
   {
      return type;
   }
   public String getDescription()
   {
      return description;
   }
   public int getWeeklyRepeat()
   {
      return weeklyRepeat;
   }
   public int getPriority()
   {
      return priority;
   }   
   
   public Calendar getcSt()
   {
      return cSt;
   }
   public Calendar getcEd()
   {
      return cEd;
   }
   
   //to test whether event is exist
   public boolean isRepeatEvent(ArrayList<Event> elist)
   {
      for(int i=0;i<elist.size();i++)
      {
         if((this.eventID).equals(elist.get(i).getEventID()))
            return true;
      }
      return false;
   }
   
   /***********************************************************************************/
   //method to get event list and convert to object list for display on the JTable
   public static ArrayList<Event> getEventList() throws Exception
   {
	   String[] stra;
	   ArrayList<Event> eventArrayList=new ArrayList<Event>();
	   //Scanner input=new Scanner(new File(GetPath.getPath()+"\\src\\comp380\\forms\\events.txt"));
	   Scanner input=new Scanner(new File(System.getProperty("user.dir")+"\\events.txt"));
	   input.nextLine();
	   input.nextLine();
	   input.nextLine();
	   //info start from the 4rd line
	   while(input.hasNext())
	   {
		   stra=input.nextLine().split("\t");
		   Event newEvent=new Event(stra);
		   eventArrayList.add(newEvent); 
	   }
	   input.close();	
	   Collections.sort(eventArrayList);   
	   return eventArrayList;   
   }
   /***********************************************************************************/
   //create object list for JTable
   public static Object[][] getObjectList(ArrayList<Event> eventArrayList,String id,Calendar calendar1)
   {
	   //delete the event not belong to the user and the day
	   for(int i=0;i<eventArrayList.size();i++)
	   {
		   String str1=""+eventArrayList.get(i).cSt.get(Calendar.YEAR)+eventArrayList.get(i).cSt.get(Calendar.MONTH)+"a"+eventArrayList.get(i).cSt.get(Calendar.DATE);
		   String str2=""+calendar1.get(Calendar.YEAR)+calendar1.get(Calendar.MONTH)+"a"+calendar1.get(Calendar.DATE);
		   String userIdInEvent=eventArrayList.get(i).getUserID();
		   if(!(str1.equals(str2)))
		   {
			   eventArrayList.remove(i);
			   i--;
		   }
		   else if(!(id.equals(userIdInEvent)))
		   {
			   eventArrayList.remove(i);
			   i--;
		   }
		   
	   }
	   int numOfRows=eventArrayList.size();
	   //fill the object list
	   Object[][] objl=new  Object[numOfRows][2];
	   for(int i=0;i<eventArrayList.size();i++)
	   {
		   Calendar sc=eventArrayList.get(i).getcSt();
		   Calendar ec=eventArrayList.get(i).getcEd();
		   objl[i][0]=""+eventArrayList.get(i).cSt.get(Calendar.HOUR_OF_DAY)+":00";
		   objl[i][1]="From "+sc.get(Calendar.HOUR_OF_DAY)+":"+((sc.get(Calendar.MINUTE)<10)?"0"+sc.get(Calendar.MINUTE):sc.get(Calendar.MINUTE))+" to "+ec.get(Calendar.HOUR_OF_DAY)+":"+((ec.get(Calendar.MINUTE)<10)?"0"+ec.get(Calendar.MINUTE):ec.get(Calendar.MINUTE))+" " +"-"+eventArrayList.get(i).description;
	   }	   
	   return objl;
   }
   public int compareTo(Event e)  
   {  
	   if (cSt.compareTo(e.cSt)<0) 
		   return - 1 ;  
	   if (cSt.compareTo(e.cSt)>0)  
		   return 1 ;  
	   return 0 ;  
   }  
   
   @Override
   public String toString()
   {
      return eventID+"\t"+userID+"\t"+type+"\t"+cSt.get(Calendar.YEAR)+"\t"+cSt.get(Calendar.MONTH)+"\t"+cSt.get(Calendar.DATE)+"\t"+cSt.get(Calendar.HOUR_OF_DAY)+"\t"+cSt.get(Calendar.MINUTE)+"\t"+cEd.get(Calendar.HOUR_OF_DAY)+"\t"+cEd.get(Calendar.MINUTE)+"\t"+description+"\t"+weeklyRepeat+"\t"+""+"\t"+""+"\t"+priority;
   }

   public void addToFile() throws Exception
   {
      PrintWriter prt=new PrintWriter(new FileOutputStream(new File(System.getProperty("user.dir")+"\\events.txt"),true));
      prt.print("\n"+toString());
      prt.close();
   
   }
}

class Lecture extends Event
{
   String professorID;
 
 
   public Lecture()
   {
   }
   
   //constructor to create new Lecture by UI
   public Lecture(String userID,int type,int year,int month,int date,int strHour,int strMin,int endHour,int endMin,String description,int weeklyRepeat,int priority,String professorID)
   {
      super(userID,type,year,month,date,strHour,strMin,endHour,endMin,description,weeklyRepeat,priority); 
      this.professorID=professorID;
   }
   //constructor to create new Lecture by table
   public Lecture(String[] stra)
   {
      super(stra);
      professorID=stra[13];
   }
   //getter
   public String getProfessorID()
   {
      return professorID;
   }
   @Override
   public String toString()
   {
      return super.toString()+"\t"+professorID;
   }   


}

class Appointment extends Event
{
   String professorID;
   int approved=0;
   
   
   public Appointment()
   {
   }
   //constructor to creat new Appointment by UI
   public Appointment(String userID,int type,int year,int month,int date,int strHour,int strMin,int endHour,int endMin,String description,int weeklyRepeat,int priority,String professorID,int approved)
   {
      super(userID,type,year,month,date,strHour,strMin,endHour,endMin,description,weeklyRepeat,priority); 
      this.professorID=professorID;
      this.approved=approved;
   }
   //constructor to creat new Appointment by table
   public Appointment(String[] stra)
   {
      super(stra);
      professorID=stra[13];
      approved=Integer.parseInt(stra[14]);
   }

   //getter
   public String getProfessorID()
   {
      return professorID;
   }
   public int getApproved()
   {
      return approved;
   }
   
   @Override
   public String toString()
   {
      return super.toString()+"\t"+professorID+approved;
   }

   
   //wait to be done
   public void setAppointment()
   {
      if(approved==0)
      {
         
      }
   }
}
