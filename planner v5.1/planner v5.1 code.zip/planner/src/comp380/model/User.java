package comp380.model;
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
import comp380.util.GetPath;

public class User
{
   String userID;
   String password;
   //1 for student. 2 for professor. 0 for others
   String userType;
   ArrayList<Event> eventList=new ArrayList<Event>();

   public User()
   {
   }

   //create user by input
   public User(String userID,String password,String userType)
   {
      this.userID=userID;
      this.password=password;
      this.userType=userType;
   }
   
   //static method
   //check registration info validity
   public static int checkRegValidity(String id,String password,String confirmPassword,String type) throws Exception
   {
      //0 valid; 1 id empty;2 password empty;3 confirmPassword empty;4 password & confirmPassword not match;5 type problem;6 existing id
      //get all the existing user id
      String[] stra;
      ArrayList<String> idArrayList=new ArrayList<String>();
      //Scanner input=new Scanner(new File(GetPath.getPath()+"\\src\\comp380\\forms\\idAndPassword.txt"));
      Scanner input=new Scanner(new File(System.getProperty("user.dir")+"\\idAndPassword.txt"));
      input.nextLine();
      input.nextLine();
      //info start from the 3rd line
      while(input.hasNext())
      {
         stra=input.nextLine().split("\t");
         idArrayList.add(stra[0]); 
      }
      input.close();
      if(id.equals(""))
         return 1;
      if(password.equals(""))
         return 2;
      if(confirmPassword.equals(""))
         return 3;   
      if(!(password.equals(confirmPassword)))
         return 4;  
      //type check not necessary because it might be a Pull-down menu
      //0 default;1 student ; 2 teacher
      if(!(type.equals("0")||type.equals("1")||type.equals("2")))
         return 5;
      for(int i=0;i<idArrayList.size();i++)
      {
         if(idArrayList.get(i).equals(id))
         {
            return 6;
         }
      }
      
      return 0;
   }
   public static void popMassage(int i)
   {
	   switch (i) {
       case 1:  JOptionPane.showMessageDialog(null, "ID cannot be empty");
                break;
       case 2:  JOptionPane.showMessageDialog(null, "The password cannot be empty");
                break;
       case 3:  JOptionPane.showMessageDialog(null, "Password Confirmation cannot be empty");
                break;
       case 4:  JOptionPane.showMessageDialog(null, "The password and confirmation password do not match");
                break;

       case 6:  JOptionPane.showMessageDialog(null, "This id is already used");

   }
	   
   }
   
   //getter
   public String getPassword()
   {
      return password;
   }
   public String getUserID()
   {
      return userID;
   }
   public ArrayList<Event> getEventList()
   {
      return eventList;
   }
   
   //setter
   //add event to the eventList
   public void addEvent(Event e)
   {
      if(!(e.isRepeatEvent(eventList)))
      {
         eventList.add(e);
      }
      else
      {
         //repeated event
      }
   }
   
   //input previous passoword,new password,confirm,new password
   public void setPassword(String newP1,String newP2)
   {
      if(newP1.equals(newP2))
         password=newP1;
   }
   
   
   
   //input previous passoword,new password,confirm,new password
   public void resetPassword(String preP,String newP1,String newP2)
   {
      if(preP.equals(password) && newP1.equals(newP2))
         password=newP1;
   }
   
   
   @Override
   public String toString()
   {
      return userID+"\t"+password+"\t"+userType;
   
   }
   //method to add user info into txt file
   public void addToFile() throws Exception
   {
      //PrintWriter prt=new PrintWriter(new FileOutputStream(new File(GetPath.getPath()+"\\src\\comp380\\forms\\idAndPassword.txt"),true));
      PrintWriter prt=new PrintWriter(new FileOutputStream(new File(System.getProperty("user.dir")+"\\idAndPassword.txt"),true));
      prt.println(toString());
      prt.close();
   
   }
   
   public static boolean userLogin(String id,String pw) throws Exception
   {
	   String[] stra;
	   ArrayList<String[]> idArrayList=new ArrayList<String[]>();
	   //Scanner input=new Scanner(new File(GetPath.getPath()+"\\src\\comp380\\forms\\idAndPassword.txt"));
	   Scanner input=new Scanner(new File(System.getProperty("user.dir")+"\\idAndPassword.txt"));
	   input.nextLine();
	   input.nextLine();
	   //info start from the 3rd line
	   while(input.hasNext())
	   {
		   stra=input.nextLine().split("\t");
		   idArrayList.add(stra); 
	   }
	   input.close();	
	   for(int i=0;i<idArrayList.size();i++)
	   {
		   if(id.equals((idArrayList.get(i))[0])&&pw.equals((idArrayList.get(i))[1]))
			   return true;
	   }
	   
	   return false;   
   }
     
}


class Student extends User
{
   ArrayList<String> finishedCourse=new ArrayList<String>();
   
   //creat user by input
   public Student(String userID,String password,String userType)
   {
      super(userID,password,userType);
   }
   //creat by table
   
   


}
