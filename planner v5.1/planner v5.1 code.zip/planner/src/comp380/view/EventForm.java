package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView.TableRow;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import comp380.model.Event;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JApplet;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class EventForm extends JFrame {

	private JPanel contentPane;
	private static String userId = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EventForm frame = new EventForm(Calendar.getInstance(),
							EventForm.userId);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public EventForm(Calendar calendar, String userId) throws Exception {
		EventForm.userId = userId;
		intiComponent(calendar);
		this.setLocationRelativeTo(null);
	}

	/**
	 * initilaize the table
	 * 
	 * @throws Exception
	 */
	private void intiComponent(final Calendar calendar) throws Exception {
		/*
		 * set JTable column name
		 */
		final Calendar c = calendar;
		String[] columnNames = { "Time", "Event Description" };

		/*
		 * create a double dimension array and fill the double dimension array
		 */

		ArrayList<Event> elist = Event.getEventList();
		Object[][] obj = Event.getObjectList(elist, EventForm.userId, calendar);

		/*
		 * create a JTable
		 */
		final JTable table = new JTable(obj, columnNames);
		table.setCellSelectionEnabled(rootPaneCheckingEnabled);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setEnabled(false);
		// ////////////////////////////////////////////////////////////////////////////////////////////
		table.addMouseListener(new MouseAdapter()

		{

			public void mouseClicked(MouseEvent e)

			{
				if (e.getClickCount() == 2)

				{

					int row = ((JTable) e.getSource()).rowAtPoint(e.getPoint());

					int col = ((JTable) e.getSource()).columnAtPoint(e.getPoint());
					String cellVal = (String) (table.getValueAt(row, col));
					String discription=cellVal.substring(1+cellVal.indexOf("-"));
					
					Deletion de=new Deletion(discription,calendar,userId);
					de.setVisible(true);
					de.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					dispose();
					//System.out.println(discription);
					

				} else
				return;
			}
		});
		// ////////////////////////////////////////////////////////////////////////////////////////////
		/*
		 * set width of JTable column
		 */
		TableColumn column = null;
		int colunms = table.getColumnCount();
		for (int i = 0; i < colunms; i++) {
			if (i == 0) {
				column = table.getColumnModel().getColumn(i);
				column.setPreferredWidth(100);
			} else {
				column = table.getColumnModel().getColumn(i);
				column.setPreferredWidth(350);

			}
		}

		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		/* put JTable into JScrollPane��if to much events we can scroll to check */
		JScrollPane scroll = new JScrollPane(table);
		scroll.setSize(300, 200);

		getContentPane().add(scroll);

		JMenuBar menuBar = new JMenuBar();
		getContentPane().add(menuBar, BorderLayout.NORTH);

		JMenu mnNewEvent = new JMenu("New Event");
		menuBar.add(mnNewEvent);

		JMenuItem mntmAddEvent = new JMenuItem("Add Event");
		mntmAddEvent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewEvent ne = new NewEvent(c, userId);
				ne.setVisible(true);
				dispose();
				// JOptionPane.showMessageDialog(null, "Not implemented yet");
			}
		});
		mnNewEvent.add(mntmAddEvent);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.pack();
	}

}
