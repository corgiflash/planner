package comp380.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import comp380.util.GetPath;
import comp380.util.StringUtil;
import comp380.model.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.ImageIcon;

public class LoginFrm extends JFrame {
	private JTextField userNameTxt;
	private JPasswordField passwordTxt;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrm frame = new LoginFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrm()  throws Exception
	{
		setResizable(false);
		setTitle("Login");
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		// centered
		this.setLocationRelativeTo(null);
		//lables
		JLabel lblNewLabel = new JLabel("SimPlan");
		lblNewLabel.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\simplan.png"));
		lblNewLabel.setFont(new Font("Dialog", Font.PLAIN, 18));
		lblNewLabel.setBounds(105, 25, 307, 47);
		getContentPane().add(lblNewLabel);

		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\userName.png"));
		lblUserId.setBounds(82, 97, 70, 15);
		getContentPane().add(lblUserId);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\password.png"));
		lblPassword.setBounds(82, 147, 91, 15);
		getContentPane().add(lblPassword);
		//text box
		userNameTxt = new JTextField();
		userNameTxt.setBounds(183, 94, 109, 21);
		getContentPane().add(userNameTxt);
		userNameTxt.setColumns(10);

		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(183, 144, 109, 21);
		getContentPane().add(passwordTxt);
		//buttoms
		JButton jbLogin = new JButton("Login");
		jbLogin.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\login.png"));
		//buttom for login
		jbLogin.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String userName=userNameTxt.getText();
				String password=new String(passwordTxt.getPassword());
				boolean matched=false;
				if(StringUtil.isEmpty(userName))
				{
					JOptionPane.showMessageDialog(null, "User name cannot be empty.");
					return;
				}
				if(StringUtil.isEmpty(password))
				{
					JOptionPane.showMessageDialog(null, "Password cannot be empty.");
					return;
				}
				/*
				try
				{
					matched=User.userLogin(userName,password);
				}
				catch(Exception exc)
				{	
				}
				*/
				try {
					matched=User.userLogin(userName,password);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(matched)
				{
					dispose();
					new MainFrm(userName).setVisible(true);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Error user id or password");
				}
			}
		});
		jbLogin.setBounds(51, 206, 93, 23);
		getContentPane().add(jbLogin);
		//buttoms for reset
		JButton jbReset = new JButton("reset");
		jbReset.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\reset.png"));
		jbReset.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				userNameTxt.setText("");
				passwordTxt.setText("");
				
			}
		});

		jbReset.setBounds(183, 206, 93, 23);
		getContentPane().add(jbReset);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\reg.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//JOptionPane.showMessageDialog(null, "Not implemented yet");
				Reg r=new Reg();
				r.setVisible(true);
			}
		});
		btnNewButton.setBounds(311, 206, 101, 23);
		getContentPane().add(btnNewButton);

	}
}


