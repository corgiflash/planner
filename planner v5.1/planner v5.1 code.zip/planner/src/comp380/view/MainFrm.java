package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	static String user="123";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm(user);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	/**
	 * Create the frame.
	 */
	public MainFrm(final String user) {
		this.user=user;
		setTitle("SimPlan");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 656, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		// centered
		this.setLocationRelativeTo(null);
		contentPane.setLayout(null);
		//max the window
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 434, 21);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("Options");
		mnNewMenu.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\base.png"));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmPlanee = new JMenuItem("Planner");
		mntmPlanee.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				//MyCalendar mc=new MyCalendar(MainFrm.user);
				MyCalendar mc=new MyCalendar(MainFrm.user);
				mc.init();
				JFrame frame = new JFrame("Calendar Application");
				  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				  frame.getContentPane().add(mc);
				  frame.setSize(240,170);
				  frame.setVisible(true);
				  //frame.setResizable(false);
				  frame.setLocationRelativeTo(null);
				  frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				//JOptionPane.showMessageDialog(null, MainFrm.user);
			}
		});
		mntmPlanee.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\calendar.png"));
		mnNewMenu.add(mntmPlanee);
		
		
		final JDesktopPane dtp;
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(0, 20, 630, 381);
		contentPane.add(desktopPane);
		dtp=desktopPane;
		
		
		JMenuItem mntmClassEnroll = new JMenuItem("Class Enrollment");
		mntmClassEnroll.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
        		AddClass nc = new AddClass( user);
        		nc.setVisible(true);
        		//dispose();
			}
		});
		mntmClassEnroll.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\bookManager.png"));
		mnNewMenu.add(mntmClassEnroll);
		
		JMenu mnNewMenu_1 = new JMenu("About Us");
		mnNewMenu_1.setIcon(new ImageIcon(System.getProperty("user.dir")+"\\about.png"));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmAboutUs = new JMenuItem("About Us");
		mntmAboutUs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "We are Team 6, the best goddamn software creation team on this good green Earth. We're creating this godly application for COMP 380 and for all our fellow Matadors.");
			}
		});
		mnNewMenu_1.add(mntmAboutUs);
		
		
		

		
		
	}
}
