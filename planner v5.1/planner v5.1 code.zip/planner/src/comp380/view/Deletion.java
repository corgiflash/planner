package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;

import comp380.model.Event;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Deletion extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//Deletion frame = new Deletion();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Deletion(final String discription,final Calendar calendarToDe, final String userId) {
		setTitle("Deletion");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel discriptionLable = new JLabel("");
		discriptionLable.setBounds(52, 34, 317, 130);
		contentPane.add(discriptionLable);
		
		JButton deleteButton = new JButton("Yes");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try 
				{
					ArrayList<Event> elist=Event.getEventList();
					Event eInList;
					for(int i=0;i<elist.size();i++)
					{
						eInList=elist.get(i);
						String discriptionInList=eInList.getDescription();
						String idInList=eInList.getUserID();
						Calendar cInList=eInList.getcSt();
						int monthToDe=calendarToDe.get(Calendar.MONTH);
						int dayToDe=calendarToDe.get(Calendar.DATE);
						int monthInList=cInList.get(Calendar.MONTH);
						int dayInList=cInList.get(Calendar.DATE);
						if(discription.equals(discriptionInList) && userId.equals(idInList) && monthToDe==monthInList && dayToDe==dayInList)
						{
							elist.remove(i);
							break;
						}
					}
					Scanner input=new Scanner(new File(System.getProperty("user.dir")+"\\events.txt"));
					String line1=input.nextLine();
					String line2=input.nextLine();
					String line3=input.nextLine();
					input.close();
					PrintWriter prt=new PrintWriter(new File(System.getProperty("user.dir")+"\\events.txt"));
				    prt.print(line1+"\n");
				    prt.print(line2+"\n");
				    prt.print(line3);
				    for(int i=0;i<elist.size();i++)
				    {
				    	elist.get(i).getcSt().set(Calendar.MONTH,1+elist.get(i).getcSt().get(Calendar.MONTH));
				    	prt.print("\n"+elist.get(i).toString());
				    }
				    prt.close();
				    EventForm ef = new EventForm(calendarToDe,userId);
				    dispose();
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		deleteButton.setBounds(64, 200, 93, 23);
		contentPane.add(deleteButton);
		
		JButton noButton = new JButton("cancel");
		noButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		noButton.setBounds(238, 200, 93, 23);
		contentPane.add(noButton);
		
		discriptionLable.setText("Are you sure you to delete "+discription + "?");
		
		
		
		
		
		
		
		this.setLocationRelativeTo(null);
	}
}
