package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import comp380.util.GetPath;
import comp380.util.StringUtil;
import comp380.model.User;


public class Reg extends JFrame {

	private JPanel contentPane;
	private JTextField userId;
	private JPasswordField passwordField1;
	private JPasswordField passwordField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reg frame = new Reg();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reg() {
		
		setTitle("Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserName = new JLabel("Username");
		lblUserName.setBounds(22, 55, 94, 15);
		contentPane.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(22, 97, 94, 15);
		contentPane.add(lblPassword);
		
		JLabel lblConfirmPassword = new JLabel("Confirm password");
		lblConfirmPassword.setBounds(22, 145, 134, 15);
		contentPane.add(lblConfirmPassword);
		
		userId = new JTextField();
		userId.setBounds(166, 52, 167, 21);
		contentPane.add(userId);
		userId.setColumns(10);
		
		passwordField1 = new JPasswordField();
		passwordField1.setBounds(166, 94, 167, 21);
		contentPane.add(passwordField1);
		
		passwordField2 = new JPasswordField();
		passwordField2.setBounds(166, 142, 167, 21);
		contentPane.add(passwordField2);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName=userId.getText();
				String password=new String(passwordField1.getPassword());
				String password2=new String(passwordField2.getPassword());
				String type=""+0;
				try {
					int validity=User.checkRegValidity(userName, password, password2,type );
					if(validity!=0)
						User.popMassage(validity);
					else
					{
						User u=new User(userName,password,type);
						u.addToFile();
						dispose();
					}
						
					
					
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, e1);
				}
				
				
			}
		});
		btnSubmit.setBounds(254, 205, 93, 23);
		contentPane.add(btnSubmit);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
}
