package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;

import comp380.model.Event;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Year;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.awt.event.ActionEvent;

public class AddClass extends JFrame {

	private JPanel contentPane;
	private JTextField classTitle;
	private JComboBox startM;


	/**
	 * Create the frame.
	 */
	public AddClass(final String user) {
		String[] hours = {"07","08","09","10","11","12","13","14","15","16","17","18","19"};
		String[] mins = {"00","05","10","15","20","25","30","35","40","45","50","55"};
		final String[] days = {"Mo","Tu","We","Th","Fr","Sat","MoWe", "TuTh"};
		final String[] semester = {"2016 Spring","2016 Fall"};		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 275, 254);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Add Class", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 10, 229, 196);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Semester :");
		lblNewLabel.setBounds(10, 26, 79, 15);
		panel.add(lblNewLabel);
		
		JLabel lblClassTitle = new JLabel("Class Title :");
		lblClassTitle.setBounds(10, 51, 79, 15);
		panel.add(lblClassTitle);
		
		classTitle = new JTextField();
		classTitle.setColumns(10);
		classTitle.setBounds(92, 48, 97, 21);
		panel.add(classTitle);
		
		JLabel lblDays = new JLabel("Days:");
		lblDays.setBounds(10, 76, 79, 15);
		panel.add(lblDays);
		
		JLabel lblTime = new JLabel("Time:");
		lblTime.setBounds(10, 101, 79, 15);
		panel.add(lblTime);
		
		final JComboBox whichSem = new JComboBox(semester);
		whichSem.setBounds(92, 23, 97, 21);
		panel.add(whichSem);
		
		final JComboBox whichDay = new JComboBox(days);
		whichDay.setBounds(92, 73, 97, 21);
		panel.add(whichDay);
		
		final JComboBox startH = new JComboBox(hours);
		startH.setBounds(65, 101, 53, 21);
		panel.add(startH);
		
		startM = new JComboBox(mins);
		startM.setBounds(136, 101, 53, 21);
		panel.add(startM);
		
		final JComboBox endH = new JComboBox(hours);
		endH.setBounds(65, 131, 53, 21);
		panel.add(endH);
		
		final JComboBox endM = new JComboBox(mins);
		endM.setBounds(136, 131, 53, 21);
		panel.add(endM);
		
		JButton submitB = new JButton("Add");
		submitB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String description = classTitle.getText();
				int strHour = Integer.parseInt((String)startH.getSelectedItem());
				int strMin = Integer.parseInt((String)startM.getSelectedItem());
				int endHour = Integer.parseInt((String)endH.getSelectedItem());
				int endMin = Integer.parseInt((String)endM.getSelectedItem());
				if(strHour>endHour)
				{
					
					JOptionPane.showMessageDialog(null, "Time Input Scheduling Error!  The end time should NOT be before the start time.", "alert", JOptionPane.ERROR_MESSAGE); 
					return;
				}
				else if(strHour == endHour)
				{
					if(strMin>endMin)
					{
						JOptionPane.showMessageDialog(null, "Time Input Scheduling Error!  The end time should NOT be before the start time.", "alert", JOptionPane.ERROR_MESSAGE); 
					      return;
					}      
				}	
				String Sem = (String)whichSem.getSelectedItem();
				String weekday =(String)whichDay.getSelectedItem();	
				int month;
				if(Sem.equals(semester[0])){
					month = 1;
					
					if(weekday.equals(days[6]))
					{
						int i=0;
						int temp1 = 25;
						int temp2 = 27;
						LocalDate date1 = Year.now().atMonth(month).atDay(temp1);
					    LocalDate date2 = Year.now().atMonth(month).atDay(temp2);
						while(i<15)
						{

							Event newEvent1 = new Event(user, 0, date1.getYear(),date1.getMonthValue()+1,date1.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date1 = date1.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent1.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							

							Event newEvent2 = new Event(user, 0, date2.getYear(),date2.getMonthValue()+1,date2.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date2 = date2.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent2.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							i++;
						}
						
					}
					else if(weekday.equals(days[7]))
					{
						int i=0;
						int temp1 = 26;
						int temp2 = 28;
						LocalDate date1 = Year.now().atMonth(month).atDay(temp1);
					    LocalDate date2 = Year.now().atMonth(month).atDay(temp2);
						while(i<15)
						{

							Event newEvent1 = new Event(user, 0, date1.getYear(),date1.getMonthValue()+1,date1.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date1 = date1.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent1.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							Event newEvent2 = new Event(user, 0, date2.getYear(),date2.getMonthValue()+1,date2.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date2 = date2.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent2.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							i++;
						}
					}
					else
					{
						int i=0;
						int temp = 23;
						if(weekday.equals(days[0]))
							temp = 25; 
						else if(weekday.equals(days[1]))
							temp = 26; 
						else if(weekday.equals(days[2]))
							temp = 27;
						else if(weekday.equals(days[3]))
							temp = 28;
						else if(weekday.equals(days[4]))
							temp = 29;
						else if(weekday.equals(days[5]))
							temp = 23;

						LocalDate date = Year.now().atMonth(month).atDay(temp);
						while(i<15)
						{							
							Event newEvent = new Event(user, 0, date.getYear(),date.getMonthValue()+1,date.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							
							date = date.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						    i++;

						}
						
					}
				}// if it is spring semester condition end
				else if(Sem.equals(semester[1])){
					month = 8;
					if(weekday.equals(days[6]))
					{
						int i=0;
						int temp1 = 28;
						int temp2 = 30;
						LocalDate date1 = Year.now().atMonth(month).atDay(temp1);
					    LocalDate date2 = Year.now().atMonth(month).atDay(temp2);
						while(i<16)
						{

							Event newEvent1 = new Event(user, 0, date1.getYear(),date1.getMonthValue()+1,date1.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date1 = date1.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent1.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							

							Event newEvent2 = new Event(user, 0, date2.getYear(),date2.getMonthValue()+1,date2.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
							date2 = date2.plus(1 , ChronoUnit.WEEKS);
							try {
								newEvent2.addToFile();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							i++;
						}
					}		
						else if(weekday.equals(days[7]))
						{
							int i=0;
							int temp1 = 29;
							int temp2 = 31;
							LocalDate date1 = Year.now().atMonth(month).atDay(temp1);
						    LocalDate date2 = Year.now().atMonth(month).atDay(temp2);
							while(i<16)
							{

								Event newEvent1 = new Event(user, 0, date1.getYear(),date1.getMonthValue()+1,date1.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
								date1 = date1.plus(1 , ChronoUnit.WEEKS);
								try {
									newEvent1.addToFile();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								Event newEvent2 = new Event(user, 0, date2.getYear(),date2.getMonthValue()+1,date2.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
								date2 = date2.plus(1 , ChronoUnit.WEEKS);
								try {
									newEvent2.addToFile();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								i++;
							}
						}
						else
						{
							int i=0;
							int temp = 28;
							if(weekday.equals(days[0]))
								temp = 29; 
							else if(weekday.equals(days[1]))
								temp = 30; 
							else if(weekday.equals(days[2]))
								temp = 31;
							else if(weekday.equals(days[3]))
							{	
								temp = 1;
								month++;
							}
							else if(weekday.equals(days[4]))
							{	
								temp = 2;
								month++;
							}
							else if(weekday.equals(days[5]))
							{	
								temp = 3;
								month++;
							}
							LocalDate date = Year.now().atMonth(month).atDay(temp);
							while(i<16)
							{							
								Event newEvent = new Event(user, 0, date.getYear(),date.getMonthValue()+1,date.getDayOfMonth(),strHour,strMin,endHour,endMin,description,0,0);
								
								date = date.plus(1 , ChronoUnit.WEEKS);
								try {
									newEvent.addToFile();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							    i++;

							}
							
						}
					
						
					
					
				}// for fall semester condition end
			 
				
				

				JOptionPane.showMessageDialog(null,"Class added");
				dispose();
			}


		});
		submitB.setBounds(115, 162, 93, 23);
		panel.add(submitB);
		
		JButton searchB = new JButton("Search");
		searchB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Thread() {
					public void run() {
						String cmd = "cmd.exe /c start ";
						String file = "https://mynorthridge.csun.edu/psp/PANRPRD/EMPLOYEE/SA/c/NR_SSS_COMMON_MENU.NR_SSS_SOC_BASIC_C.GBL?&";
						
						try {

							Runtime.getRuntime().exec(cmd + file);
						} catch (IOException ignore) {
							ignore.printStackTrace();
						}
					}
				}.start();
			}
		});
		searchB.setBounds(12, 162, 93, 23);
		panel.add(searchB);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  
		this.setLocationRelativeTo(null);
	}
}
