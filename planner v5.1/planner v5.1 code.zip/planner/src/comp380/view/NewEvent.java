package comp380.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JFormattedTextField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.border.BevelBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;

import comp380.model.Event;

import javax.swing.border.MatteBorder;
import javax.swing.UIManager;

public class NewEvent extends JFrame {
	private JTextField eventDiscripition;

	public NewEvent(final Calendar calendar,final String userId) {
		//String[] chioceString={"Appointment", "Entertaiment", "Meeting", "Sport"};
		String[] hours = {"00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23"};
		String[] mins = {"00","05","10","15","20","25","30","35","40","45","50","55"};
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 490, 211);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "New Event", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(4, 3, 466, 156);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel NewEventForm = new JPanel();
		NewEventForm.setBounds(6, 17, 454, 132);
		panel.add(NewEventForm);
		NewEventForm.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Start Time\uFF1A");
		lblNewLabel.setBounds(10, 13, 74, 15);
		NewEventForm.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("End Time\uFF1A");
		lblNewLabel_1.setBounds(237, 13, 74, 15);
		NewEventForm.add(lblNewLabel_1);
		
		final JComboBox startH = new JComboBox(hours);
		startH.setBounds(80, 10, 53, 21);
		NewEventForm.add(startH);
	
		
		final JComboBox startM = new JComboBox(mins);
		startM.setBounds(144, 10, 53, 21);
		NewEventForm.add(startM);
		
		final JComboBox endH = new JComboBox(hours);
		endH.setBounds(303, 10, 53, 21);
		NewEventForm.add(endH);
		
		final JComboBox endM = new JComboBox(mins);
		endM.setBounds(367, 10, 46, 21);
		NewEventForm.add(endM);
		
		final JLabel lblDiscription = new JLabel("Description");
		lblDiscription.setBounds(10, 52, 74, 15);
		NewEventForm.add(lblDiscription);
		
		eventDiscripition = new JTextField();
		eventDiscripition.setBounds(10, 77, 346, 45);
		NewEventForm.add(eventDiscripition);
		eventDiscripition.setColumns(10);
		
		JButton submitButton = new JButton("Submit");
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int year = calendar.get(Calendar.YEAR);
				int month = calendar.get(Calendar.MONTH)+2 ;
				int date = calendar.get(Calendar.DAY_OF_MONTH);
				int strHour = Integer.parseInt((String)startH.getSelectedItem());
				int strMin = Integer.parseInt((String)startM.getSelectedItem());
				int endHour = Integer.parseInt((String)endH.getSelectedItem());
				int endMin = Integer.parseInt((String)endM.getSelectedItem());
				String description = eventDiscripition.getText();
				if(strHour>endHour)
				{
					
					JOptionPane.showMessageDialog(null, "Time Input Scheduling Error!  The end time should NOT be before the start time.", "alert", JOptionPane.ERROR_MESSAGE); 
					return;
				}
				else if(strHour == endHour)
				{
					if(strMin>endMin)
					{
						JOptionPane.showMessageDialog(null, "Time Input Scheduling Error!  The end time should NOT be before the start time.", "alert", JOptionPane.ERROR_MESSAGE); 
					      return;
					}      
				}	
				Event newEvent = new Event(userId, 0, year,month,date,strHour,strMin,endHour,endMin,description,0,0);	
				try {
					newEvent.addToFile();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					EventForm ef = new EventForm(calendar,userId);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				dispose();
			}
		});
		submitButton.setBounds(367, 99, 77, 23);
		NewEventForm.add(submitButton);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
	}
}
