package comp380.view;

import javax.swing.JApplet;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;


public class MyCalendar extends JApplet {
 
	// set the value for table head
	public String SUNDAY = "SUN"; 
	public String MONDAY = "MON"; 
	public String TUESDAY = "TUE"; 
	public String WEDNESDAY = "WED"; 
	public String THURSDAY = "THU"; 
	public String FRIDAY = "FRI"; 
	public String SATERDAY = "SAT";

    // background color
    public Color bgColor = Color.white; 
    // foreground color
    public Color fgColor = Color.black; 
    // set color for title
    public Color hbgColor = Color.blue; 
    public Color hfgColor = Color.white; 
    // set the color for clicked cell
    public Color sbgColor = Color.blue; 
    public Color sfgColor = Color.white;
    private static String userId = "";
    
    //the parts of GUI
    private JPanel currPane; 
    // year
    private JLabel yLable; 
    // change year
    private JSpinner ySpinner; 
    // month
    private JLabel mLabel; 
    // drop-down menu for month
    private JComboBox mComboBox; 
    // the table to display date
    private JTable dTable; 
    //dVM
    private AbstractTableModel dVM; 
    private Calendar calendarForSelectedDay; 
    
    // constructor for panel
    public MyCalendar(String userId) { 
    	currPane = (JPanel) getContentPane(); 
        MyCalendar.userId = userId;
    }
 
	// initialize table arrangement
    public void init() { 
    	currPane.setLayout(new BorderLayout());
    	// use border manage the arrangement
    	calendarForSelectedDay = Calendar.getInstance(); 
        yLable = new JLabel("Year: "); 
        ySpinner = new JSpinner();
        
        ySpinner.setEditor(new JSpinner.NumberEditor(ySpinner, "0000"));
        ySpinner.setValue(new Integer(calendarForSelectedDay.get(Calendar.YEAR))); 
        // listener for year change
        ySpinner.addChangeListener(new ChangeListener() { 
                public void stateChanged(ChangeEvent changeEvent) { 
                    int day = calendarForSelectedDay.get(Calendar.DAY_OF_MONTH);
                    calendarForSelectedDay.set(Calendar.DAY_OF_MONTH, 1);
                    calendarForSelectedDay.set(Calendar.YEAR, ((Integer) ySpinner.getValue()).intValue());
                    int maxDay = calendarForSelectedDay.getActualMaximum(Calendar.DAY_OF_MONTH);
                    calendarForSelectedDay.set(Calendar.DAY_OF_MONTH, day > maxDay ? maxDay : day);
                    updateView(); 
                } 
            });
 
        //container for the year and month selector
        JPanel ymPanel = new JPanel(); 
        currPane.add(ymPanel, BorderLayout.NORTH); 
        ymPanel.setLayout(new BorderLayout()); 
        ymPanel.add(new JPanel(), BorderLayout.CENTER); 
        JPanel yPanel = new JPanel(); 
        ymPanel.add(yPanel, BorderLayout.WEST); 
        yPanel.setLayout(new BorderLayout()); 
        yPanel.add(yLable, BorderLayout.WEST); 
        yPanel.add(ySpinner, BorderLayout.CENTER);
 
        // set value for ComboBox
        mLabel = new JLabel("Month: "); 
        mComboBox = new JComboBox(); 
        for (int i = 1; i <= 12; i++) { 
        	mComboBox.addItem(new Integer(i)); 
        } 
        mComboBox.setSelectedIndex(calendarForSelectedDay.get(Calendar.MONTH)); 
        // listener for month change
        mComboBox.addActionListener(new ActionListener() { 
                public void actionPerformed(ActionEvent actionEvent) {
                    int day = calendarForSelectedDay.get(Calendar.DAY_OF_MONTH);
                    calendarForSelectedDay.set(Calendar.DAY_OF_MONTH, 1);
                    calendarForSelectedDay.set(Calendar.MONTH, mComboBox.getSelectedIndex());
                    int maxDay = calendarForSelectedDay.getActualMaximum(Calendar.DAY_OF_MONTH);
                    calendarForSelectedDay.set(Calendar.DAY_OF_MONTH, day > maxDay ? maxDay : day);
                    updateView(); 
                } 
            }); 
        JPanel monthPanel = new JPanel(); 
        ymPanel.add(monthPanel, BorderLayout.EAST); 
        monthPanel.setLayout(new BorderLayout()); 
        monthPanel.add(mLabel, BorderLayout.WEST); 
        monthPanel.add(mComboBox, BorderLayout.CENTER);
 
        
        
        dVM = new AbstractTableModel() { 
        		// seven row
                public int getRowCount() { 
                    return 7; 
                }
                // seven column
                public int getColumnCount() { 
                    return 7; 
                }
 
                public Object getValueAt(int row, int column) { 
                    if (row == 0) { 
                        return getHeader(column); 
                    } 
                    row--; 
                    Calendar calendar = (Calendar) MyCalendar.this.calendarForSelectedDay.clone();
                    calendar.set(Calendar.DAY_OF_MONTH, 1);
                    int dayCount = calendar.getActualMaximum(Calendar.DAY_OF_MONTH); 
                    int moreDayCount = calendar.get(Calendar.DAY_OF_WEEK) - 1; 
                    int index = row * 7 + column; 
                    int dayIndex = index - moreDayCount + 1;
                    if (index < moreDayCount || dayIndex > dayCount) { 
                        return null; 
                    } else { 
                        return new Integer(dayIndex); 
                    } 
                } 
            };
 
            
        dTable = new myCalendarTable(calendarForSelectedDay,dVM ); 
        // set each cell to be selectable
        dTable.setCellSelectionEnabled(true);
        dTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		// create the UI for the events of the double clicked day
        dTable.addMouseListener(new MouseAdapter()

		{

			public void mouseClicked(MouseEvent e)

			{
				if (e.getClickCount() == 2)

				{

					try {
						EventForm ef = new EventForm(calendarForSelectedDay,
								MyCalendar.userId);
					} catch (Exception ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}

				} else
				return;
			}
		});

        //single click to change the selected day
        dTable.setDefaultRenderer(dTable.getColumnClass(0), new TableCellRenderer() 
        { 
        	
                public Component getTableCellRendererComponent(JTable table, Object dayValue, boolean cellSelected, 
                                                               boolean hasFocus, int row, int column) { 
                    String text = (dayValue == null) ? "" : dayValue.toString(); 
                    JLabel cell = new JLabel(text); 
                    cell.setOpaque(true); 
                    if (row == 0) { 
                        cell.setForeground(hfgColor); 
                        cell.setBackground(hbgColor); 
                    } else { 
                        if (cellSelected) { 
                            cell.setForeground(sfgColor); 
                            cell.setBackground(sbgColor); 
                        } else { 
                            cell.setForeground(fgColor); 
                            cell.setBackground(bgColor); 
                        } 
                    }
 
                    return cell; 
                } 
            });
        updateView();
        
        //add the table to the jpanel
        currPane.add(dTable, BorderLayout.CENTER); 
    }
    
 
    public  String getHeader(int index) { 
        switch (index) { 
        case 0: 
            return SUNDAY; 
        case 1: 
            return MONDAY; 
        case 2: 
            return TUESDAY; 
        case 3: 
            return WEDNESDAY; 
        case 4: 
            return THURSDAY; 
        case 5: 
            return FRIDAY; 
        case 6: 
            return SATERDAY; 
        default: 
            return null; 
        } 
    }
 
    //after change the selected day,update the view of the table
    public void updateView() { 
    	dVM.fireTableDataChanged();
        dTable.setRowSelectionInterval(calendarForSelectedDay.get(Calendar.WEEK_OF_MONTH),
        		calendarForSelectedDay.get(Calendar.WEEK_OF_MONTH));
        dTable.setColumnSelectionInterval(calendarForSelectedDay.get(Calendar.DAY_OF_WEEK) - 1,
        		calendarForSelectedDay.get(Calendar.DAY_OF_WEEK) - 1);
    }


    public static class myCalendarTable extends JTable {
        private Calendar c;
        public myCalendarTable(Calendar calendar,TableModel tModel) {
            super(tModel);
            this.c = calendar;
        }
        public void changeSelection(int rows, int columns, boolean isToggle, boolean isExtended) {
            super.changeSelection(rows, columns, isToggle, isExtended);
            if (rows == 0) {
                return;
            }
            Object object = getValueAt(rows, columns);
            if (object != null) {
                c.set(Calendar.DAY_OF_MONTH, ((Integer)object).intValue());
            }
        }
    }

}