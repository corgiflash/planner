package comp380.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ClassEnrollmentInterFrm extends JInternalFrame {
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClassEnrollmentInterFrm frame = new ClassEnrollmentInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClassEnrollmentInterFrm() {
		setIconifiable(true);
		setClosable(true);
		setTitle("Class Enrollment");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblHahaha = new JLabel("Enroll in Class");
		lblHahaha.setBounds(84, 20, 54, 15);
		getContentPane().add(lblHahaha);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"name", "password", "disc"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(139);
		table.getColumnModel().getColumn(1).setPreferredWidth(190);
		table.getColumnModel().getColumn(2).setPreferredWidth(196);
		table.setBounds(22, 51, 300, 200);
		getContentPane().add(table);

	}
}
